AI 合成语音(Synthetic audio):仅限本人或已获明确授权的声音;不得伪装成真人原始录音。

播放精确副本:PCM int16 单声道,与实际发给浏览器的样本序列逐样本一致。TTS worker 在送出前已量化为 int16,因此无法恢复量化前的 float 音频;FLAC 版本只是同一批 int16 样本的无损封装。

每个 manifest.json 含 SHA-256;默认不含文本、参考音频、声纹向量。
